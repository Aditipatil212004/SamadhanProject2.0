const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const { registerUser, loginUser, getMe } = require('../controllers/authController');
const authMiddleware = require('../middleware/authMiddleware');


// @route POST /api/auth/register
// required fields: name, email, password
router.post(
'/register',
[
body('name', 'Name is required').notEmpty(),
body('email', 'Please include a valid email').isEmail(),
body('password', 'Password min 6 chars').isLength({ min: 6 }),
],
registerUser
);


// @route POST /api/auth/login
router.post(
'/login',
[body('email', 'Please include a valid email').isEmail(), body('password', 'Password is required').exists()],
loginUser
);


// @route GET /api/auth/me (protected)
router.get('/me', authMiddleware, getMe);
router.get("/protected", authMiddleware, (req, res) => {
  res.json({ message: "You have access to this protected route!", user: req.user });
});

module.exports = router;