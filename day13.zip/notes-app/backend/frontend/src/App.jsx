import React, { useEffect, useState } from 'react';
import axios from 'axios';
import NoteForm from './components/NoteForm';
import NoteList from './components/NoteList';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL
});

export default function App() {
  const [notes, setNotes] = useState([]);
  const [editingNote, setEditingNote] = useState(null);

  const fetchNotes = async () => {
    try {
      const res = await api.get('/notes');
      setNotes(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => { fetchNotes(); }, []);

  const createNote = async (note) => {
    try {
      const res = await api.post('/notes', note);
      setNotes(prev => [res.data, ...prev]);
    } catch (err) { console.error(err); }
  };

  const updateNote = async (id, updated) => {
    try {
      const res = await api.put(`/notes/${id}`, updated);
      setNotes(prev => prev.map(n => n._id === id ? res.data : n));
      setEditingNote(null);
    } catch (err) { console.error(err); }
  };

  const deleteNote = async (id) => {
    try {
      await api.delete(`/notes/${id}`);
      setNotes(prev => prev.filter(n => n._id !== id));
    } catch (err) { console.error(err); }
  };

  return (
  <div className="app">
    <div className="header">
      <h1 className="title">📝 Notes App</h1>
      <span className="badge">CRUD + Mongoose</span>
    </div>

    <div className="card padded">
      <NoteForm
        onCreate={createNote}
        onUpdate={updateNote}
        editingNote={editingNote}
        cancelEdit={() => setEditingNote(null)}
      />
    </div>

    <div className="hr"></div>

    <NoteList
      notes={notes}
      onEdit={note => setEditingNote(note)}
      onDelete={deleteNote}
    />
  </div>
);

   
}
