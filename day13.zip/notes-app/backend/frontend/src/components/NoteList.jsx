import React from 'react';
import NoteItem from './NoteItem';

export default function NoteList({ notes, onEdit, onDelete }) {
  if (!notes.length) return <p className="muted">No notes yet. Add your first one above!</p>;
  return (
    <div className="list">
      {notes.map(note => (
        <NoteItem key={note._id} note={note} onEdit={onEdit} onDelete={onDelete} />
      ))}
    </div>
  );
}
