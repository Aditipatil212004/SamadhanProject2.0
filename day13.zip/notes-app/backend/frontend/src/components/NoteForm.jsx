import React, { useEffect, useState } from 'react';

export default function NoteForm({ onCreate, onUpdate, editingNote, cancelEdit }) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  useEffect(() => {
    if (editingNote) {
      setTitle(editingNote.title || '');
      setContent(editingNote.content || '');
    } else {
      setTitle('');
      setContent('');
    }
  }, [editingNote]);

  const submit = (e) => {
    e.preventDefault();
    if (!title.trim()) return alert('Title required');

    if (editingNote) onUpdate(editingNote._id, { title, content });
    else onCreate({ title, content });
  };

  return (
    <form onSubmit={submit} className="form">
      <div className="row">
        <input
          className="input"
          value={title}
          onChange={e => setTitle(e.target.value)}
          placeholder="Note title (e.g., Project ideas, Grocery list)"
        />
        <textarea
          className="textarea"
          value={content}
          onChange={e => setContent(e.target.value)}
          placeholder="Write your note here…"
          rows={4}
        />
      </div>
      <div className="actions">
        <button type="submit" className={editingNote ? "btn btn-accent" : "btn btn-primary"}>
          {editingNote ? 'Update Note' : 'Add Note'}
        </button>
        {editingNote && (
          <button type="button" onClick={cancelEdit} className="btn btn-secondary">
            Cancel
          </button>
        )}
      </div>
    </form>
  );
}
