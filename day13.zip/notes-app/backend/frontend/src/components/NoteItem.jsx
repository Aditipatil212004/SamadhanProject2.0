import React from 'react';

export default function NoteItem({ note, onEdit, onDelete }) {
  return (
    <div className="note">
      <div className="note-head">
        <h3 className="note-title">{note.title}</h3>
        <small className="note-time">
          {new Date(note.createdAt).toLocaleString()}
        </small>
      </div>

      <div className="note-body">{note.content}</div>

      <div className="note-actions">
        <button className="btn btn-secondary" onClick={() => onEdit(note)}>Edit</button>
        <button
          className="btn btn-danger"
          onClick={() => {
            if (confirm('Delete this note?')) onDelete(note._id);
          }}
        >
          Delete
        </button>
      </div>
    </div>
  );
}
