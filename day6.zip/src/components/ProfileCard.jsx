import { useState } from "react";
import "./ProfileCard.css";

export default function ProfileCard({ name, role, avatar, bio, location, website }) {
  const [followed, setFollowed] = useState(false);

  const handleContact = () => {
    alert(`Contacting ${name}...`);
  };

  return (
    <article className="pcard" aria-label={`Profile card for ${name}`}>
      <img className="pcard__avatar" src={avatar} alt={`${name} avatar`} loading="lazy" />
      <div className="pcard__body">
        <h2 className="pcard__name">{name}</h2>
        {role && <p className="pcard__role">{role}</p>}
        {bio && <p className="pcard__bio">{bio}</p>}

        <div className="pcard__meta">
          {location && <span className="meta__item">{location}</span>}
          {website && <a className="meta__item" href={website} target="_blank" rel="noreferrer">Website</a>}
        </div>

        <div className="pcard__actions">
          <button className="pcard__btn" onClick={() => setFollowed(v => !v)}>{followed ? "Unfollow" : "Follow"}</button>
          <button className="pcard__btn pcard__btn--ghost" onClick={handleContact}>Contact</button>
        </div>
      </div>
    </article>
  );
}
