import { useMemo, useState } from "react";
import "./App.css";

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [text, setText] = useState("");
  const [filter, setFilter] = useState("all"); // 'all' | 'active' | 'completed'
  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState("");

  const remainingCount = useMemo(
    () => tasks.filter((t) => !t.done).length,
    [tasks]
  );

  const visibleTasks = useMemo(() => {
    if (filter === "active") return tasks.filter((t) => !t.done);
    if (filter === "completed") return tasks.filter((t) => t.done);
    return tasks;
  }, [tasks, filter]);

  const addTask = () => {
    const trimmed = text.trim();
    if (!trimmed) return;
    setTasks((prev) => [
      { id: Date.now(), text: trimmed, done: false },
      ...prev,
    ]);
    setText("");
  };

  const handleAddKey = (e) => {
    if (e.key === "Enter") addTask();
  };

  const toggleTask = (id) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, done: !t.done } : t))
    );
  };

  const deleteTask = (id) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  const clearCompleted = () => {
    setTasks((prev) => prev.filter((t) => !t.done));
  };

  const startEdit = (id, currentText) => {
    setEditingId(id);
    setEditText(currentText);
  };

  const commitEdit = () => {
    if (editingId == null) return;
    const trimmed = editText.trim();
    setTasks((prev) =>
      prev.map((t) =>
        t.id === editingId ? { ...t, text: trimmed || t.text } : t
      )
    );
    setEditingId(null);
    setEditText("");
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditText("");
  };

  return (
    <div className="wrapper">
      <div className="card">
        <header className="header">
          <h1>To-Do List</h1>
          <p className="sub">Local state only • No storage</p>
        </header>

        <div className="addRow">
          <input
            className="input"
            type="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={handleAddKey}
            placeholder="What needs to be done?"
            aria-label="New task"
          />
          <button className="btn primary" onClick={addTask} aria-label="Add task">
            Add
          </button>
        </div>

        <div className="toolbar">
          <div className="filters" role="tablist" aria-label="Filter tasks">
            <button
              className={`chip ${filter === "all" ? "active" : ""}`}
              onClick={() => setFilter("all")}
              role="tab"
              aria-selected={filter === "all"}
            >
              All
            </button>
            <button
              className={`chip ${filter === "active" ? "active" : ""}`}
              onClick={() => setFilter("active")}
              role="tab"
              aria-selected={filter === "active"}
            >
              Active
            </button>
            <button
              className={`chip ${filter === "completed" ? "active" : ""}`}
              onClick={() => setFilter("completed")}
              role="tab"
              aria-selected={filter === "completed"}
            >
              Completed
            </button>
          </div>

          <div className="meta">
            <span>{remainingCount} left</span>
            <button
              className="btn subtle"
              onClick={clearCompleted}
              disabled={!tasks.some((t) => t.done)}
            >
              Clear completed
            </button>
          </div>
        </div>

        <ul className="list" aria-live="polite">
          {visibleTasks.length === 0 && (
            <li className="empty">Nothing here yet. Add a task!</li>
          )}

          {visibleTasks.map((t) => (
            <li key={t.id} className={`item ${t.done ? "done" : ""}`}>
              <label className="left">
                <input
                  type="checkbox"
                  checked={t.done}
                  onChange={() => toggleTask(t.id)}
                  aria-label={`Toggle ${t.text}`}
                />
                {editingId === t.id ? (
                  <input
                    className="editInput"
                    value={editText}
                    onChange={(e) => setEditText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") commitEdit();
                      if (e.key === "Escape") cancelEdit();
                    }}
                    onBlur={commitEdit}
                    autoFocus
                  />
                ) : (
                  <span
                    className="text"
                    onDoubleClick={() => startEdit(t.id, t.text)}
                    title="Double-click to edit"
                  >
                    {t.text}
                  </span>
                )}
              </label>

              <div className="actions">
                {editingId !== t.id && (
                  <button
                    className="iconBtn"
                    onClick={() => startEdit(t.id, t.text)}
                    aria-label="Edit"
                    title="Edit"
                  >
                    ✏️
                  </button>
                )}
                <button
                  className="iconBtn danger"
                  onClick={() => deleteTask(t.id)}
                  aria-label="Delete"
                  title="Delete"
                >
                  🗑️
                </button>
              </div>
            </li>
          ))}
        </ul>

        <footer className="footer">
          <small>Tip: double-click a task to edit • Press Esc to cancel</small>
        </footer>
      </div>
    </div>
  );
}
