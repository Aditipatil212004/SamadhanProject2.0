import { useState } from "react";
import ProductCard from "./ProductCard";

const products = [
  {
    id: 1,
    name: "Wireless Headphones",
    category: "Electronics",
    price: 2999,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSwITGgBy6zUwkloFFalzsL71ZWSTrYzX_1Bg&s",
  },
  {
    id: 2,
    name: "Running Shoes",
    category: "Sports",
    price: 4999,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRf90elSC8I51TyvvKq6s2WFNVHNF7vf6e89A&s",
  },
  {
    id: 3,
    name: "Smart Watch",
    category: "Gadgets",
    price: 7999,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTw30JocizVF45BZursdsQefc856jCeexUWIQ&s",
  },
  {
    id: 4,
    name: "Gaming Mouse",
    category: "Electronics",
    price: 1999,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRA87D8MEP44Uo2vrqMPJgClJ2iMFdqzT6cSg&s",
  },
  {
    id: 5,
    name: "Yoga Mat",
    category: "Sports",
    price: 999,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwXXedGoTYMV0B2_VDbBC75yF5PCX_H1hLLg&s",
  },
];

function App() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");

  const filteredProducts = products.filter((p) => {
    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = category === "All" || p.category === category;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <h1 className="text-3xl font-bold text-center mb-6">🛍 Product List</h1>

      {/* 🔎 Search & Filter */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-8">
        <input
          type="text"
          placeholder="Search products..."
          className="px-4 py-2 border rounded-xl w-full sm:w-1/2 focus:outline-none focus:ring-2 focus:ring-blue-400"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        <select
          className="px-4 py-2 border rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-400"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          <option value="All">All</option>
          <option value="Electronics">Electronics</option>
          <option value="Sports">Sports</option>
          <option value="Gadgets">Gadgets</option>
        </select>
      </div>

      {/* 🟦 Product Grid */}
      <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-3">
        {filteredProducts.length > 0 ? (
          filteredProducts.map((p) => <ProductCard key={p.id} product={p} />)
        ) : (
          <p className="col-span-full text-center text-gray-500">
            ❌ No products found
          </p>
        )}
      </div>
    </div>
  );
}

export default App;
