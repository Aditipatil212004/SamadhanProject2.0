// client/src/contexts/AuthContext.jsx
import React, { createContext, useContext, useState } from "react";

const AuthContext = createContext();

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [registeredUsers, setRegisteredUsers] = useState([]);

  const signup = (email, password) => {
  const exists = registeredUsers.find((u) => u.email === email);
  if (exists) return { error: "User already exists. Please login." };

  const newUser = { email, password };
  setRegisteredUsers([...registeredUsers, newUser]);

  // Automatically log in after signup


  return { success: true };
};


  const login = (email, password) => {
    const existingUser = registeredUsers.find((u) => u.email === email);
    if (!existingUser) return { error: "No account found. Please sign up first." };
    if (existingUser.password !== password) return { error: "Incorrect password." };
    setUser(existingUser);
    return { success: true };
  };

  const logout = () => setUser(null);

  const resetPassword = (email) => {
  const existingUser = registeredUsers.find((u) => u.email === email);
  if (!existingUser) return { error: "No account found with this email." };

  // Simulate sending reset email
  // In real app, backend would send actual email
  return { success: true, message: `Password reset link sent to ${email}!` };
};


  return (
    <AuthContext.Provider value={{ user, signup, login, logout, resetPassword }}>
      {children}
    </AuthContext.Provider>
  );
}
