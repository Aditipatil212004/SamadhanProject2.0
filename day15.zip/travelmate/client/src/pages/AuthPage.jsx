import React, { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { useNavigate } from "react-router-dom";

function AuthPage() {
  const { signup, login, resetPassword } = useAuth();
  const navigate = useNavigate();

  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [message, setMessage] = useState("");
  const [showResetModal, setShowResetModal] = useState(false);
  const [resetEmail, setResetEmail] = useState("");
  const [resetMessage, setResetMessage] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    setMessage("");

    if (isLogin) {
      const result = login(email, password);
      if (result.error) return setMessage(result.error);
      navigate("/dashboard");
    } else {
      if (password !== confirmPassword) return setMessage("Passwords do not match!");
      const result = signup(email, password);
      if (result.error) return setMessage(result.error);
      setIsLogin(true);
      setMessage("Signup successful! Please log in.");
      setEmail(""); setPassword(""); setConfirmPassword("");
    }
  };

  const handleResetPassword = () => {
    setResetMessage("");
    if (!resetEmail) return setResetMessage("Enter your email.");
    const result = resetPassword(resetEmail);
    if (result.error) return setResetMessage(result.error);
    setResetMessage(result.message);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="bg-white p-8 rounded-2xl shadow-lg w-full max-w-md">
        <div className="flex justify-between mb-6">
          <button
            onClick={() => setIsLogin(true)}
            className={`px-4 py-2 font-bold rounded-tl-xl rounded-tr-xl ${
              isLogin ? "bg-blue-600 text-white" : "bg-gray-200"
            }`}
          >
            Login
          </button>
          <button
            onClick={() => setIsLogin(false)}
            className={`px-4 py-2 font-bold rounded-tl-xl rounded-tr-xl ${
              !isLogin ? "bg-blue-600 text-white" : "bg-gray-200"
            }`}
          >
            Sign Up
          </button>
        </div>

        {message && (
          <p className="text-center mb-4 text-red-600 font-semibold">{message}</p>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <input
            type="email"
            placeholder="Email"
            className="border p-2 rounded"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Password"
            className="border p-2 rounded"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          {!isLogin && (
            <input
              type="password"
              placeholder="Confirm Password"
              className="border p-2 rounded"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
            />
          )}

          <button
            type="submit"
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition"
          >
            {isLogin ? "Login" : "Sign Up"}
          </button>

          {isLogin && (
            <button
              type="button"
              onClick={() => setShowResetModal(true)}
              className="text-blue-600 mt-2 hover:underline text-sm"
            >
              Forgot Password?
            </button>
          )}
        </form>
      </div>

      {/* Reset Password Modal */}
      {showResetModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-2xl shadow-lg w-96 relative">
            <h3 className="text-xl font-bold mb-4">Reset Password</h3>
            {resetMessage && (
              <p className="text-green-600 font-semibold mb-2">{resetMessage}</p>
            )}
            <input
              type="email"
              placeholder="Enter your email"
              className="border p-2 rounded w-full mb-4"
              value={resetEmail}
              onChange={(e) => setResetEmail(e.target.value)}
            />
            <div className="flex justify-between">
              <button
                onClick={() => {
                  setShowResetModal(false);
                  setResetEmail("");
                  setResetMessage("");
                }}
                className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400"
              >
                Cancel
              </button>
              <button
                onClick={handleResetPassword}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
              >
                Send Link
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default AuthPage;
