/*import React from "react";

function Dashboard() {
  return <h2 className="p-10 text-2xl">Dashboard Page</h2>;
}

export default Dashboard;


import React from "react";
import { useAuth } from "../contexts/AuthContext";

function Dashboard() {
  const { user, logout } = useAuth();

  return (
    <div className="p-10">
      <h2 className="text-2xl font-bold">Dashboard</h2>
      {user ? (
        <div className="mt-4">
          <p>Welcome, {user.email} 🎉</p>
          <button
            onClick={logout}
            className="mt-4 bg-red-600 text-white px-4 py-2 rounded"
          >
            Logout
          </button>
        </div>
      ) : (
        <p className="mt-4">Not logged in.</p>
      )}
    </div>
  );
}

export default Dashboard;



import React from "react";
import { useAuth } from "../contexts/AuthContext";

function Dashboard() {
  const { user, logout } = useAuth();

  return (
    <div className="p-10">
      <h2 className="text-2xl font-bold">Dashboard</h2>
      {user ? (
        <div className="mt-4">
          <p>Welcome, {user.email} 🎉</p>
          <button
            onClick={logout}
            className="mt-4 bg-red-600 text-white px-4 py-2 rounded"
          >
            Logout
          </button>
        </div>
      ) : (
        <p className="mt-4 text-red-600">You must log in first.</p>
      )}
    </div>
  );
}

export default Dashboard;*/

// client/src/pages/Dashboard.jsx
import React, { useState } from "react"; // <-- add useState
import { useAuth } from "../contexts/AuthContext";


function Dashboard() {
  const { user, logout } = useAuth();
  const [trips, setTrips] = useState([
  // Dummy trips (you can replace with API later)
  
    {
      id: 1,
      destination: "Paris, France",
      date: "2025-10-15",
      image: "https://res.cloudinary.com/dtljonz0f/image/upload/c_fill,w_3840,g_auto/f_auto/q_auto:eco/v1/Paris-hp-banner_kzqphg?_a=BAVAZGE70",
    },
    {
      id: 2,
      destination: "Tokyo, Japan",
      date: "2025-11-02",
      image: "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/13/7f/b3/b7/asakusa.jpg?w=500&h=500&s=1",
    },
    {
      id: 3,
      destination: "New York, USA",
      date: "2025-12-20",
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqAS-ddEmizMAand1WLw0nRtEPfZ_JO_Nexg&s",
    },
  ]);
  const [showModal, setShowModal] = useState(false);
  const [newTrip, setNewTrip] = useState({
    destination: "",
    date: "",
    image: "",
  });

  const handleAddTrip = (e) => {
    e.preventDefault();
    const id = trips.length + 1;
    setTrips([...trips, { id, ...newTrip }]);
    setNewTrip({ destination: "", date: "", image: "" });
    setShowModal(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-bold text-blue-700">
          Welcome, {user?.email.split("@")[0]} 👋
        </h2>
        <button
          onClick={logout}
          className="bg-red-600 text-white px-4 py-2 rounded shadow hover:bg-red-700 transition"
        >
          Logout
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-10">
        <div className="bg-white p-6 rounded-2xl shadow text-center">
          <h3 className="text-xl font-bold">Trips Booked</h3>
          <p className="text-3xl text-blue-600 mt-2">{trips.length}</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow text-center">
          <h3 className="text-xl font-bold">Upcoming Trips</h3>
          <p className="text-3xl text-green-600 mt-2">
            {trips.filter(
              (t) => new Date(t.date) > new Date()
            ).length}
          </p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow text-center">
          <h3 className="text-xl font-bold">Wishlist</h3>
          <p className="text-3xl text-purple-600 mt-2">5</p>
        </div>
      </div>

       <h3 className="text-2xl font-bold mb-4">Your Upcoming Trips</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {trips.map((trip) => (
          <div
            key={trip.id}
            className="bg-white rounded-2xl shadow overflow-hidden hover:shadow-lg transition"
          >
            <img
              src={
                trip.image ||
                `https://source.unsplash.com/400x250/?travel,${trip.destination}`
              }
              alt={trip.destination}
              className="w-full h-40 object-cover"
            />
            <div className="p-4 text-left">
              <h4 className="text-lg font-bold">{trip.destination}</h4>
              <p className="text-gray-600">📅 {trip.date}</p>
            </div>
          </div>
        ))}
      </div>


      {/* CTA */}
      <div className="mt-10 text-center">
        <button
          onClick={() => setShowModal(true)}
          className="bg-blue-600 text-white px-6 py-3 rounded-lg shadow hover:bg-blue-700 transition"
        >
          ➕ Plan a New Trip
        </button>
      </div>
    
  
{/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-2xl shadow-lg w-96 relative">
            <h3 className="text-xl font-bold mb-4">Plan a New Trip</h3>
            <form onSubmit={handleAddTrip} className="flex flex-col gap-4">
              <input
                type="text"
                placeholder="Destination"
                className="border p-2 rounded"
                value={newTrip.destination}
                onChange={(e) =>
                  setNewTrip({ ...newTrip, destination: e.target.value })
                }
                required
              />
              <input
                type="date"
                className="border p-2 rounded"
                value={newTrip.date}
                onChange={(e) =>
                  setNewTrip({ ...newTrip, date: e.target.value })
                }
                required
              />
              <input
                type="text"
                placeholder="Image URL (optional)"
                className="border p-2 rounded"
                value={newTrip.image}
                onChange={(e) =>
                  setNewTrip({ ...newTrip, image: e.target.value })
                }
              />
              <div className="flex justify-between">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                >
                  Save Trip
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}


export default Dashboard;



