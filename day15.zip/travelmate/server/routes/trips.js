const express = require('express');
const router = express.Router();
const Trip = require('../models/Trip');
const auth = require('../middleware/auth');


// Get all trips (public)
router.get('/', async (req, res) => {
try {
const trips = await Trip.find().populate('createdBy', 'name email').sort({ createdAt: -1 });
res.json(trips);
} catch (err) {
console.error(err.message);
res.status(500).send('Server error');
}
});


// Get single trip
router.get('/:id', async (req, res) => {
try {
const trip = await Trip.findById(req.params.id).populate('createdBy', 'name email');
if (!trip) return res.status(404).json({ message: 'Trip not found' });
res.json(trip);
} catch (err) {
console.error(err.message);
res.status(500).send('Server error');
}
});


// Create trip (protected)
router.post('/', auth, async (req, res) => {
try {
const { title, location, description, price, duration, image } = req.body;
const trip = new Trip({ title, location, description, price, duration, image, createdBy: req.user._id });
await trip.save();
res.json(trip);
} catch (err) {
console.error(err.message);
res.status(500).send('Server error');
}
});


// Update trip (protected, owner only)
router.put('/:id', auth, async (req, res) => {
try {
const trip = await Trip.findById(req.params.id);
if (!trip) return res.status(404).json({ message: 'Trip not found' });
if (trip.createdBy.toString() !== req.user._id.toString()) return res.status(403).json({ message: 'Not authorized' });


const { title, location, description, price, duration, image } = req.body;
trip.title = title ?? trip.title;
trip.location = location ?? trip.location;
trip.description = description ?? trip.description;
trip.price = price ?? trip.price;
trip.duration = duration ?? trip.duration;
trip.image = image ?? trip.image;


await trip.save();
res.json(trip);
} catch (err) {
console.error(err.message);
res.status(500).send('Server error');
}
});


// Delete trip (protected, owner only)
router.delete('/:id', auth, async (req, res) => {
try {
const trip = await Trip.findById(req.params.id);
if (!trip) return res.status(404).json({ message: 'Trip not found' });
if (trip.createdBy.toString() !== req.user._id.toString()) return res.status(403).json({ message: 'Not authorized' });


await trip.remove();
res.json({ message: 'Trip removed' });
} catch (err) {
console.error(err.message);
res.status(500).send('Server error');
}
});


module.exports = router;