const mongoose = require('mongoose');


const TripSchema = new mongoose.Schema({
title: { type: String, required: true },
location: { type: String, required: true },
description: { type: String },
price: { type: Number, default: 0 },
duration: { type: String },
image: { type: String },
createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
}, { timestamps: true });


module.exports = mongoose.model('Trip', TripSchema);