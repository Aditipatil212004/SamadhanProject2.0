import React, { useState } from 'react';

export default function CounterLivePreview() {
  // state for counter and text
  const [count, setCount] = useState(0);
  const [text, setText] = useState('');

  // counter handlers
  const increment = () => setCount(c => c + 1);
  const decrement = () => setCount(c => c - 1);
  const reset = () => {
    setCount(0);
    setText('');
  };

  // derived values for text preview
  const charCount = text.length;
  const wordCount = text.trim() === '' ? 0 : text.trim().split(/\s+/).length;

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-6">
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-lg p-6">
        <h1 className="text-2xl font-semibold mb-4">Counter + Live Text Preview</h1>

        {/* Counter section */}
        <section className="mb-6">
          <h2 className="text-lg font-medium mb-2">Counter</h2>
          <div className="flex items-center gap-3">
            <button
              aria-label="decrement"
              onClick={decrement}
              className="px-3 py-1 rounded-lg border hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-300"
            >
              −
            </button>

            <div className="text-xl font-bold w-20 text-center" aria-live="polite">{count}</div>

            <button
              aria-label="increment"
              onClick={increment}
              className="px-3 py-1 rounded-lg border hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-300"
            >
              +
            </button>

            <button
              onClick={reset}
              className="ml-auto text-sm text-gray-600 hover:underline focus:outline-none"
            >
              Reset
            </button>
          </div>
        </section>

        {/* Live text preview section */}
        <section className="mb-6">
          <h2 className="text-lg font-medium mb-2">Live Text Preview</h2>

          <textarea
            className="w-full border rounded-lg p-3 min-h-[120px] resize-y focus:outline-none focus:ring-2 focus:ring-indigo-200"
            placeholder="Type something here..."
            value={text}
            onChange={(e) => setText(e.target.value)}
          />

          <div className="mt-2 text-sm text-gray-600 flex gap-4">
            <div>Chars: <strong>{charCount}</strong></div>
            <div>Words: <strong>{wordCount}</strong></div>
          </div>

          <div className="mt-4 p-4 border rounded-lg bg-gray-50">
            <h3 className="text-sm font-medium mb-1">Preview</h3>
            <div className="whitespace-pre-wrap">{text || <span className="text-gray-400">Nothing yet — start typing.</span>}</div>
          </div>
        </section>

        <div className="text-sm text-gray-500">Tip: The preview updates instantly as you type.</div>
      </div>
    </div>
  );
}
