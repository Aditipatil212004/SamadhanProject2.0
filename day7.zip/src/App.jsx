import React from 'react'
import CounterLivePreview from './components/CounterLivePreview'

export default function App() {
  return <CounterLivePreview />
}
