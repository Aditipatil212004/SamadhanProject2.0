import express from "express";
import cors from "cors";
import { JSONFilePreset } from "lowdb/node";
import { v4 as uuid } from "uuid";

const app = express();
const PORT = process.env.PORT || 5000;

// Simple file DB: server/db.json (auto-created)
const db = await JSONFilePreset("db.json", { todos: [] });

app.use(cors());
app.use(express.json());

// Health check
app.get("/api/health", (req, res) => {
  res.json({ ok: true, time: new Date().toISOString() });
});

// List todos
app.get("/api/todos", (req, res) => {
  // newest first
  const items = [...db.data.todos].sort((a, b) => b.createdAt - a.createdAt);
  res.json(items);
});

// Create todo
app.post("/api/todos", async (req, res) => {
  const { text } = req.body || {};
  if (!text || !text.trim()) {
    return res.status(400).json({ error: "text is required" });
  }
  const now = Date.now();
  const todo = {
    id: uuid(),
    text: text.trim(),
    done: false,
    createdAt: now,
    updatedAt: now
  };
  db.data.todos.push(todo);
  await db.write();
  res.status(201).json(todo);
});

// Update todo (partial: text and/or done)
app.patch("/api/todos/:id", async (req, res) => {
  const { id } = req.params;
  const { text, done } = req.body || {};
  const todo = db.data.todos.find((t) => t.id === id);
  if (!todo) return res.status(404).json({ error: "not found" });

  if (typeof text === "string") {
    if (!text.trim()) return res.status(400).json({ error: "text cannot be empty" });
    todo.text = text.trim();
  }
  if (typeof done === "boolean") {
    todo.done = done;
  }
  todo.updatedAt = Date.now();
  await db.write();
  res.json(todo);
});

// Delete todo
app.delete("/api/todos/:id", async (req, res) => {
  const { id } = req.params;
  const idx = db.data.todos.findIndex((t) => t.id === id);
  if (idx === -1) return res.status(404).json({ error: "not found" });
  const [removed] = db.data.todos.splice(idx, 1);
  await db.write();
  res.json(removed);
});

app.listen(PORT, () => {
  console.log(`API running on http://localhost:${PORT}`);
});
