import { useEffect, useState } from "react";
import "./App.css";

export default function App() {
  const [todos, setTodos] = useState([]);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState(null);
  const [error, setError] = useState("");

  // Load on mount
  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/todos");
        const data = await res.json();
        setTodos(data);
      } catch (e) {
        setError("Failed to load todos");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  async function addTodo(e) {
    e.preventDefault();
    setError("");
    const val = text.trim();
    if (!val) return;
    try {
      const res = await fetch("/api/todos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: val }),
      });
      if (!res.ok) throw new Error("Create failed");
      const created = await res.json();
      setTodos((t) => [created, ...t]);
      setText("");
    } catch (e) {
      setError("Could not create todo");
    }
  }

  async function toggleDone(id, done) {
    setBusyId(id);
    setError("");
    try {
      const res = await fetch(`/api/todos/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ done: !done }),
      });
      if (!res.ok) throw new Error("Update failed");
      const updated = await res.json();
      setTodos((list) => list.map((t) => (t.id === id ? updated : t)));
    } catch (e) {
      setError("Could not update todo");
    } finally {
      setBusyId(null);
    }
  }

  async function editText(id, currentText) {
    const next = prompt("Edit todo text:", currentText);
    if (next === null) return; // cancelled
    const val = next.trim();
    if (!val) return alert("Text cannot be empty.");
    setBusyId(id);
    setError("");
    try {
      const res = await fetch(`/api/todos/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: val }),
      });
      if (!res.ok) throw new Error("Update failed");
      const updated = await res.json();
      setTodos((list) => list.map((t) => (t.id === id ? updated : t)));
    } catch (e) {
      setError("Could not update text");
    } finally {
      setBusyId(null);
    }
  }

  async function remove(id) {
    if (!confirm("Delete this todo?")) return;
    setBusyId(id);
    setError("");
    try {
      const res = await fetch(`/api/todos/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Delete failed");
      setTodos((list) => list.filter((t) => t.id !== id));
    } catch (e) {
      setError("Could not delete todo");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="wrap">
      <h1>To-Do App</h1>

      <form onSubmit={addTodo} className="row">
        <input
          className="input"
          placeholder="Add a task and press Enter"
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        <button className="btn primary" type="submit">Add</button>

      </form>

      {error && <div className="error">{error}</div>}
      {loading ? (
        <div className="muted">Loading…</div>
      ) : todos.length === 0 ? (
        <div className="muted">No tasks yet. Add one!</div>
      ) : (
        <ul className="list">
          {todos.map((t) => (
            <li key={t.id} className={`item ${t.done ? "done" : ""}`}>
              <label className="left">
                <input
                  type="checkbox"
                  checked={t.done}
                  disabled={busyId === t.id}
                  onChange={() => toggleDone(t.id, t.done)}
                />
                <span>{t.text}</span>
              </label>
              <div className="actions">
                <button className="btn ghost" disabled={busyId === t.id} onClick={() => editText(t.id, t.text)}>
                  Edit
                </button>
                <button className="btn danger" disabled={busyId === t.id} onClick={() => remove(t.id)}>
                  Delete
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
