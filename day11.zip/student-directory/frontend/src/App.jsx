import { useEffect, useState } from "react";
import "./App.css";

function App() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ name: "", age: "", course: "" });
  const [editingId, setEditingId] = useState(null);

  // ✅ Fetch students
  useEffect(() => {
    fetch("http://localhost:5000/api/students")
      .then((res) => res.json())
      .then((data) => {
        setStudents(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Error fetching students:", err);
        setLoading(false);
      });
  }, []);

  // ✅ Handle form input
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  // ✅ Add / Update student
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (editingId) {
      // update
      const res = await fetch(`http://localhost:5000/api/students/${editingId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const updated = await res.json();
      setStudents(students.map((s) => (s.id === editingId ? updated : s)));
      setEditingId(null);
    } else {
      // add new
      const res = await fetch("http://localhost:5000/api/students", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const newStudent = await res.json();
      setStudents([...students, newStudent]);
    }

    setForm({ name: "", age: "", course: "" });
  };

  // ✅ Edit student
  const handleEdit = (student) => {
    setForm(student);
    setEditingId(student.id);
  };

  // ✅ Delete student
  const handleDelete = async (id) => {
    await fetch(`http://localhost:5000/api/students/${id}`, {
      method: "DELETE",
    });
    setStudents(students.filter((s) => s.id !== id));
  };

  return (
    <div className="container">
      <h1>🎓 Student Directory</h1>

      {/* 📝 Add / Update Form */}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="name"
          placeholder="Enter name"
          value={form.name}
          onChange={handleChange}
          required
        />
        <input
          type="number"
          name="age"
          placeholder="Enter age"
          value={form.age}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="course"
          placeholder="Enter course"
          value={form.course}
          onChange={handleChange}
          required
        />
        <button type="submit">
          {editingId ? "Update Student" : "Add Student"}
        </button>
      </form>

      {/* 👩‍🎓 Student List */}
      {loading ? (
        <p>Loading students...</p>
      ) : (
        <div className="student-list">
          {students.map((student) => (
            <div key={student.id} className="student-card">
              <h2>{student.name}</h2>
              <p>{student.age} years old</p>
              <p>
                Enrolled in <b>{student.course}</b>
              </p>
              <div className="actions">
                <button onClick={() => handleEdit(student)}>✏️ Edit</button>
                <button className="delete" onClick={() => handleDelete(student.id)}>
                  ❌ Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default App;
