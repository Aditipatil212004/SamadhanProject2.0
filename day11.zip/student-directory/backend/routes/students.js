const express = require('express');
const router = express.Router();
const path = require('path');

// Import lowdb correctly
const { Low } = require('lowdb');
const { JSONFile } = require('lowdb/node');

// lowdb setup
const file = path.join(__dirname, '..', 'db.json');
const adapter = new JSONFile(file);
const defaultData = { students: [] };   // ✅ provide default data
const db = new Low(adapter, defaultData);

// Ensure DB is always read before use
async function readDB() {
  await db.read();
}

function genId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

// ------------------- ROUTES ------------------- //

// GET /api/students -> list all students
router.get('/', async (req, res) => {
  await readDB();
  res.json(db.data.students);
});

// GET /api/students/:id -> single student
router.get('/:id', async (req, res) => {
  await readDB();
  const student = db.data.students.find(s => s.id === req.params.id);
  if (!student) return res.status(404).json({ message: 'Student not found' });
  res.json(student);
});
// Add a new student
router.post("/", async (req, res) => {
  await db.read();
  const { name, age, course } = req.body;

  if (!name || !age || !course) {
    return res.status(400).json({ error: "All fields are required" });
  }

  const newStudent = {
    id: Date.now().toString(),
    name,
    age,
    course,
  };

  db.data.students.push(newStudent);
  await db.write();

  res.status(201).json(newStudent);
});
// Delete a student
router.delete("/:id", async (req, res) => {
  await db.read();
  const { id } = req.params;

  const studentIndex = db.data.students.findIndex((s) => s.id === id);
  if (studentIndex === -1) {
    return res.status(404).json({ error: "Student not found" });
  }

  const deletedStudent = db.data.students.splice(studentIndex, 1);
  await db.write();

  res.json(deletedStudent[0]);
});


  // Update a student
router.put("/:id", async (req, res) => {
  await db.read();
  const { id } = req.params;
  const { name, age, course } = req.body;

  const student = db.data.students.find((s) => s.id === id);
  if (!student) {
    return res.status(404).json({ error: "Student not found" });
  }

  // Update fields
  student.name = name;
  student.age = age;
  student.course = course;

  await db.write();
  res.json(student);
});


// POST /api/students -> add new student
router.post('/', async (req, res) => {
  await readDB();
  const { name, age, course } = req.body;
  if (!name || !course) return res.status(400).json({ message: 'name and course required' });

  const newStudent = { id: genId(), name, age: Number(age) || null, course };
  db.data.students.push(newStudent);
  await db.write();
  res.status(201).json(newStudent);
});

// PUT /api/students/:id -> update student
router.put('/:id', async (req, res) => {
  await readDB();
  const { name, age, course } = req.body;
  const idx = db.data.students.findIndex(s => s.id === req.params.id);
  if (idx === -1) return res.status(404).json({ message: 'Student not found' });

  db.data.students[idx] = { ...db.data.students[idx], name, age: Number(age) || null, course };
  await db.write();
  res.json(db.data.students[idx]);
});

// DELETE /api/students/:id -> delete student
router.delete('/:id', async (req, res) => {
  await readDB();
  const idx = db.data.students.findIndex(s => s.id === req.params.id);
  if (idx === -1) return res.status(404).json({ message: 'Student not found' });
  const removed = db.data.students.splice(idx, 1)[0];
  await db.write();
  res.json({ message: 'Deleted', student: removed });
});

module.exports = router;
