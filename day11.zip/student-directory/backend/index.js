const express = require('express');
const cors = require('cors');
const studentsRouter = require('./routes/students');


const app = express();
app.use(cors());
app.use(express.json());


// mount API
app.use('/api/students', studentsRouter);


const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Backend running on http://localhost:${PORT}`));
app.get('/', (req, res) => {
  res.send('Student Directory API is running 🚀. Use /api/students');
});
